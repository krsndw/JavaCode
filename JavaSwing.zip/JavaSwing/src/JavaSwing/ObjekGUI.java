package JavaSwing;

import com.toedter.calendar.JDateChooser;
import java.awt.Color;
import javax.swing.*;

public class ObjekGUI {

    public static void main(String[] args) {
        GUI g = new GUI();
    }
}

class GUI extends JFrame {

    JLabel lnamadpn = new JLabel("Nama Depan");
    final JTextField fnamadpn = new JTextField(10);

    JLabel lnamablkng = new JLabel("Nama Belakang");
    final JTextField fnamablkng = new JTextField(10);

    JLabel lnomoremail = new JLabel("Nomor seluler atau Email");
    final JTextField fnomoremail = new JTextField(50);

    JLabel lpassword = new JLabel("Password");
    final JPasswordField fpassword = new JPasswordField(50);

    JLabel ltgllhr = new JLabel("Tanggal Lahir");
    JDateChooser ftgllhr = new JDateChooser();

    JLabel ljeniskelamin = new JLabel("Jenis Kelamin");
    JRadioButton rblaki = new JRadioButton("Laki-laki");
    JRadioButton rbperempuan = new JRadioButton("Perempuan");

    JLabel lagama = new JLabel("Agama");
    String[] namaAgama = {"Islam", "Kristen", "Katolik", "Hindu", "Buddha"};
    JComboBox cmagama = new JComboBox(namaAgama);

    JLabel lsuka = new JLabel("Apa yang kamu sukai?");
    JCheckBox cbgames = new JCheckBox("Games");
    JCheckBox cbseni = new JCheckBox("Seni");
    JCheckBox cbmusik = new JCheckBox("Musik");
    JCheckBox cbolahraga = new JCheckBox("Olahraga");
    JCheckBox cbfilm = new JCheckBox("Film");
    JCheckBox cbmakanan = new JCheckBox("Makanan");

    JButton bdaftar = new JButton("Daftar");

    public GUI() {
        setTitle("Daftar Facebook");
        setSize(445, 380);
        this.getContentPane().setBackground(Color.green);

        ButtonGroup group = new ButtonGroup();
        group.add(rblaki);
        group.add(rbperempuan);

        setLayout(null);
        add(lnamadpn);
        add(fnamadpn);
        add(lnamablkng);
        add(fnamablkng);
        add(lnomoremail);
        add(fnomoremail);
        add(lpassword);
        add(fpassword);
        add(ltgllhr);
        add(ftgllhr);
        add(ljeniskelamin);
        add(rblaki);
        add(rbperempuan);
        add(lagama);
        add(cmagama);
        add(lsuka);
        add(cbgames);
        add(cbseni);
        add(cbmusik);
        add(cbolahraga);
        add(cbfilm);
        add(cbmakanan);
        add(bdaftar);

        lnamadpn.setBounds(10, 10, 150, 20);
        fnamadpn.setBounds(160, 10, 100, 20);
        lnamablkng.setBounds(10, 35, 150, 20);
        fnamablkng.setBounds(160, 35, 100, 20);
        lnomoremail.setBounds(10, 85, 150, 20);
        fnomoremail.setBounds(160, 85, 155, 20);
        lpassword.setBounds(10, 110, 150, 20);
        fpassword.setBounds(160, 110, 155, 20);
        ltgllhr.setBounds(10, 160, 150, 20);
        ftgllhr.setBounds(160, 160, 180, 20);
        ljeniskelamin.setBounds(10, 185, 150, 20);
        rblaki.setBounds(160, 185, 75, 20);
        rbperempuan.setBounds(240, 185, 100, 20);
        lagama.setBounds(10, 210, 150, 20);
        cmagama.setBounds(160, 210, 100, 20);
        lsuka.setBounds(10, 235, 130, 20);
        cbgames.setBounds(160, 235, 75, 20);
        cbseni.setBounds(240, 235, 75, 20);
        cbolahraga.setBounds(320, 235, 100, 20);
        cbfilm.setBounds(160, 260, 75, 20);
        cbmusik.setBounds(240, 260, 75, 20);
        cbmakanan.setBounds(320, 260, 100, 20);
        bdaftar.setBounds(180, 310, 75, 20);

        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

}
